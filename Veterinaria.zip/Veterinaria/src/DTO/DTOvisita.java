/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DTO;


import java.time.LocalDate;

/**
 *
 * @author Pc
 */
public class DTOvisita {
    private String detalles;
    private LocalDate fechaVisita;

    public DTOvisita(String detalles, LocalDate fechaVisita) {
        this.detalles = detalles;
        this.fechaVisita = fechaVisita;
    }

    public String getDetalles() {
        return detalles;
    }

    public void setDetalles(String detalles) {
        this.detalles = detalles;
    }

    public LocalDate getFechaVisita() {
        return fechaVisita;
    }

    public void setFechaVisita(LocalDate fechaVisita) {
        this.fechaVisita = fechaVisita;
    }
    
    
}
