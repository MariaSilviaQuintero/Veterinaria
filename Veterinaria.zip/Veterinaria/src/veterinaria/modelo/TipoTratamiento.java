
package veterinaria.modelo;

/**
 *
 * @author Mauri
 * 
 */
public class TipoTratamiento {
    
    
    private String nombreTipoTratamiento;
    
    public TipoTratamiento(){}

    public TipoTratamiento(String nombreTipoTratamiento) {
        this.nombreTipoTratamiento = nombreTipoTratamiento;
    }

    public String getNombreTipoTratamiento() {
        return nombreTipoTratamiento;
    }

    public void setNombreTipoTratamiento(String nombreTipoTratamiento) {
        this.nombreTipoTratamiento = nombreTipoTratamiento;
    }
    

    
}
