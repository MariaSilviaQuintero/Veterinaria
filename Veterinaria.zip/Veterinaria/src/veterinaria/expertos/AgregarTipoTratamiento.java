package veterinaria.expertos;

import veterinaria.datas.TipoTratamientoData;
import veterinaria.modelo.TipoTratamiento;

/**
 *
 * @author mauri
 * 
 */
public class AgregarTipoTratamiento {
    
    private TipoTratamiento tipoTratamiento;
    private TipoTratamientoData tipoTratamientoData;
    
    
    public void agregarTipoTratamiento (String nombreTipoTratamiento){
        
        tipoTratamiento = new TipoTratamiento(nombreTipoTratamiento);
        tipoTratamientoData.guardarTipoTratamiento(nombreTipoTratamiento);
        
    }
    
}
